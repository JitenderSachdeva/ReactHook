import React, { useState, useEffect } from "react";
import AddTodo from "./components/AddTodo";
import './App.css';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import { useDispatch, useSelector } from "react-redux";
import { makeStyles } from '@material-ui/core/styles';
import Todo from "./components/Todo";
import CssBaseline from '@material-ui/core/CssBaseline';
import EditTodo from './components/EditTodo';
import { retrieveTodo, } from "./store/actions/TodoAction";


const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      margin: theme.spacing(1),
    },
  },
  icon: {
    marginRight: theme.spacing(2),
  },
  bodys: {
    margin: theme.spacing(1),
    width: '25ch',
  },
  heroContent: {
    backgroundColor: theme.palette.background.paper,
    padding: theme.spacing(8, 0, 6),
  },
  heroButtons: {
    marginTop: theme.spacing(4),
  },
  cardGrid: {
    paddingTop: theme.spacing(8),
    paddingBottom: theme.spacing(8),
  },
  card: {
    height: '100%',
    display: 'flex',
    flexDirection: 'column',
  },
  cardMedia: {
    paddingTop: '56.25%', // 16:9
  },
  cardContent: {
    flexGrow: 1,
  },
  title: {
    flexGrow: 1,
  },
  footer: {
    backgroundColor: theme.palette.background.paper,
    padding: theme.spacing(6),
  },
}));

function App() {
  const initialFormState = {
    id: null,
    title: "",
    body: "",
  };
  const classes = useStyles();
  const [currentTodo, setCurrentTodo] = useState(initialFormState);
  const [editing, setEditing] = useState(false);
  const dispatch = useDispatch();
  const tutorials = useSelector(state => state.Todos);
  useEffect(() => {
    dispatch(retrieveTodo());
  }, []);

  const editRow = todos => {
    setEditing(true);
    setCurrentTodo({ id: todos.id, title: todos.title, body: todos.body })
  }
  const cancelHandler = () => {
    setEditing(false);
  }

  console.log(currentTodo)

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" color="inherit" className={classes.title}>
            Todo List
          </Typography>
        </Toolbar>
      </AppBar>
      <>
        {editing ? (
          <>
            < EditTodo
              classes={classes}
              editing={editing}
              onClose={cancelHandler}
              currentTodo={currentTodo}
            />
          </>
        ) : (
          <>
            <AddTodo classes={classes} onClose={cancelHandler} />
            <Todo classes={classes} editRow={editRow} />
          </>
        )}
      </>
      <footer className={classes.footer}>
        <Typography variant="h6" align="center" gutterBottom>
          Footer
        </Typography>
        <Typography variant="subtitle1" align="center" color="textSecondary" component="p">
          Something here to give the footer a purpose!
        </Typography>
      </footer>
    </>
  );
}

export default App;