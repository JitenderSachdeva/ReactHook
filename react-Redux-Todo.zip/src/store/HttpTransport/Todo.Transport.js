import axios from "axios";

export default axios.create({
    baseURL: "https://60ae52e05b8c300017dea3a3.mockapi.io",
    headers: {
        "Content-type": "application/json"
    }
})