import { CREATE_TODO, RETRIEVE_TODO, UPDATE_TODO, DELETE_TODO } from "../contants/Todo.actionTypes";

const initialState = [];

function TodoReducer(todos = initialState, action) {
    const { type, payload } = action;

    switch (type) {
        case CREATE_TODO:
            return [...todos, payload];

        case RETRIEVE_TODO:
            return payload;

        case UPDATE_TODO:
            return todos.map((todos) => {
                if (todos.id === todos.id) {
                    return {
                        ...todos,
                        ...payload,
                    };
                } else {
                    return todos;
                }
            });

        case DELETE_TODO:
            return todos.filter(({ id }) => id !== payload.id);

        default:
            return todos;
    }
};

export default TodoReducer;