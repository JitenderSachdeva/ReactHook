import { ActionTypes } from "../contants/action-types";

const initialState = {
    loading: false,
    news: [],
    error: ''
}

const newsReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'FETCH_NEWS_REQUEST':
            return { ...state, loading: true }
        case 'FETCH_NEWS_SUCCESS':
            return {
                loading: false, news: action.payload, error: ''
            }
        case 'FETCH_COUNTRIES_FAILURE':
            return {
                loading: false,
                countries: [],
                error: action.payload
            }
        default: return state;
    }
}

export default newsReducer;