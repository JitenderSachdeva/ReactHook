import { combineReducers } from 'redux';
import newsReducer from "./NewsReducer";
import TodoReducer from "./TodoReducer";

const reducers = combineReducers({
    allNews: newsReducer,
    Todos: TodoReducer,
});

export default reducers;