export const CREATE_TODO = "CREATE_TODO";
export const RETRIEVE_TODO = "RETRIEVE_TODO";
export const UPDATE_TODO = "UPDATE_TODO";
export const DELETE_TODO = "DELETE_TODO";