import { fetchNewsRequest, setNews, fetchNewsFailure } from '../contants/action-types';
import axios from 'axios';

// call API
export const fetchNews = () => {
    return (dispatch) => {
        dispatch(fetchNewsRequest())
        axios
            .get('https://newsapi.org/v2/top-headlines?country=us&apiKey=f8e0c1b1130043919581596de9a48bd2')
            .then(response => {
                const news = response.data;
                setTimeout(() => {  // to emulate some network delay
                    dispatch(setNews(news.articles))
                }, 2000)
            })
            .catch(error => {
                dispatch(fetchNewsFailure(error.message))
            })
    }
}

