import { CREATE_TODO, RETRIEVE_TODO, UPDATE_TODO, DELETE_TODO } from "../contants/Todo.actionTypes";
import TutorialService from "../HttpTransport/Services/TodoServices";

export const createTodo = (title, body) => async (dispatch) => {
    try {
        const res = await TutorialService.create({ title, body });

        dispatch({
            type: CREATE_TODO,
            payload: res.data,
        });
        return Promise.resolve(res.data);
    } catch (err) {
        return Promise.reject(err);
    }
};

export const retrieveTodo = (id) => async (dispatch) => {
    try {
        const res = await TutorialService.getAll();
        dispatch({
            type: RETRIEVE_TODO,
            payload: res.data,
        });
    } catch (err) {
        console.log(err);
    }
};

export const updateTodo = (id, data) => async (dispatch) => {
    console.log(id)
    try {
        const res = await TutorialService.update(id, data);

        dispatch({
            type: UPDATE_TODO,
            payload: data,
        });

        return Promise.resolve(res.data);
    } catch (err) {
        return Promise.reject(err);
    }
};

export const deleteTodo = (id) => async (dispatch) => {
    try {
        await TutorialService.remove(id);

        dispatch({
            type: DELETE_TODO,
            payload: { id },
        });
    } catch (err) {
        console.log(err);
    }
};

export const findTutorialsByTitle = (title) => async (dispatch) => {
    try {
        const res = await TutorialService.findByTitle(title);

        dispatch({
            type: RETRIEVE_TODO,
            payload: res.data,
        });
    } catch (err) {
        console.log(err);
    }
};
