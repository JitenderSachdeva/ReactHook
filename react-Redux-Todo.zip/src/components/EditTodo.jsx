import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { updateTodo, deleteTodo } from "../store/actions/TodoAction";
import Container from '@material-ui/core/Container';
import FormControl from '@material-ui/core/FormControl';
import TextField from '@material-ui/core/TextField';
import { Box } from "@material-ui/core";
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import TodoServices from "../store/HttpTransport/Services/TodoServices";


const EditTodo = (props) => {
    const classes = props.classes;
    const dispatch = useDispatch();
    const initialTutorialState = {
        id: null,
        title: "",
        body: "",
    };
    const [currentTodo, setCurrentTodo] = useState(initialTutorialState);
    const [message, setMessage] = useState("");
    const getTodo = id => {
        TodoServices.get(id)
            .then(response => {
                setCurrentTodo(response.data);
                console.log(response.data);
            })
            .catch(e => {
                console.log(e);
            });
    };
    //console.log(props.editRow)
    useEffect(() => {
        getTodo(props.currentTodo.id);
    }, [props.currentTodo.id]);


    const handleInputChange = event => {
        const { name, value } = event.target;
        setCurrentTodo({ ...currentTodo, [name]: value });
    };


    const updateContent = () => {
        dispatch(updateTodo(currentTodo.id, currentTodo))
            .then(response => {
                console.log(response);
                setMessage("The tutorial was updated successfully!");
                setTimeout(() => {
                    props.onClose()
                }, 1200);
            })
            .catch(e => {
                console.log(e);
            });
    };

    const CancelTodo = () => {
        props.onClose();
    };

    return (
        <>

            <div className={classes.heroContent}>

                <Typography variant="h6" align="center" gutterBottom>Edit New Todo</Typography>
                <Container maxWidth="sm">
                    <Box mb="2rem">
                        <FormControl fullWidth variant="outlined">
                            <TextField name="title" value={currentTodo.title}
                                onChange={handleInputChange} id="outlined-search" label={"Title"} type="search" variant="outlined" />
                        </FormControl>
                    </Box>

                    <Box mb="2rem">
                        <FormControl fullWidth className={classes.margin} variant="outlined">
                            <TextField name="body" value={currentTodo.body}
                                onChange={handleInputChange} id="outlined-search" label={"Text"} type="search" variant="outlined" />
                        </FormControl>
                    </Box>
                    <div className={classes.root}>
                        <Button variant="contained" mar color="primary" onClick={updateContent}>Submit</Button>
                        <Button variant="contained" color="primary" onClick={CancelTodo}>Cancel</Button>
                    </div>

                    <Box mt="1rem">
                        <Typography gutterBottom variant="h6" align="center" color="primary" component="h5">
                            {message}
                        </Typography>
                    </Box>
                    <Typography variant="subtitle1" align="center" color="textSecondary" component="p">
                    </Typography>
                </Container>
            </div>

        </>
    )
}

export default EditTodo;