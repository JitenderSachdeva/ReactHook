import React, { useEffect } from "react";
import { deleteTodo, retrieveTodo, } from "../store/actions/TodoAction";
import { useSelector, useDispatch } from "react-redux";
import Button from '@material-ui/core/Button';
import Container from '@material-ui/core/Container';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';

const Todo = (props) => {
    console.log(props)
    const classes = props.classes;
    const dispatch = useDispatch();
    const tutorials = useSelector(state => state.Todos);

    useEffect(() => {
        dispatch(retrieveTodo());
    }, []);

    const removeTodo = (id) => {
        dispatch(deleteTodo(id))
    }

    return (
        <>
            <main>
                {/* Hero unit */}
                <Container className={classes.cardGrid} maxWidth="md">
                    {/* End hero unit */}
                    <Grid container spacing={4}>
                        {tutorials.map((card) => (
                            <Grid item key={card} xs={12} sm={6} md={4}>
                                <Card className={classes.card}>
                                    <CardContent className={classes.cardContent}>
                                        <Typography gutterBottom variant="h6" component="h5">
                                            {card.title}
                                        </Typography>
                                        <Typography>
                                            {card.body}
                                        </Typography>
                                    </CardContent>
                                    <CardActions>
                                        <Button size="small" color="primary" onClick={() => removeTodo(card.id)}> Delete </Button>
                                        <Button size="small" color="primary" onClick={() => { props.editRow(card) }}>
                                            Edit </Button>
                                    </CardActions>
                                </Card>
                            </Grid>
                        ))}
                    </Grid>
                </Container>
            </main>
            {/* Footer */}
        </>
    )
}
export default Todo;